//
//  SoundsViewController.swift
//  Serenity
//
//  Created by Harold  on 3/2/16.
//  Copyright © 2016 Harold . All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class SoundsViewController: UIViewController {
    var playerViewController = AVPlayerViewController()
    var playerView = AVPlayer()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func music1Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Downloads/Calming Seas #1 - 11 Hours Ocean Sound for relaxation, yoga, meditation, reading, sleep, study.mp3")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
        }

    }
    

    @IBAction func music2Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Downloads/mystic brew Ronnie Foster.mp3")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
        }

    }
    
    @IBAction func music3Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Downloads/Relax 8 Hours - Relaxing Nature Sounds-Study-Sleep-Meditation-Water Sounds-Bird Song.mp3")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
        }

    }
}
