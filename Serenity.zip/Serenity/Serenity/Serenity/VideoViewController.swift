//
//  VideoViewController.swift
//  Serenity
//
//  Created by Harold  on 2/29/16.
//  Copyright © 2016 Harold . All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class VideoViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    var playerViewController = AVPlayerViewController()
    var playerView = AVPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.navigationBar.hidden = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func video1Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Desktop/Serenity/Serenity/Serenity/video1.mp4")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
            }
    }
    
    @IBAction func video2Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Downloads/video2.mp4")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
        }
    }
    
    @IBAction func video3Button(sender: AnyObject) {
        let fileURL = NSURL(fileURLWithPath: "/Users/mac/Downloads/video3.mp4")
        playerView = AVPlayer(URL: fileURL)
        playerViewController.player = playerView
        
        //code below present viewcontroller to screen
        self.presentViewController(playerViewController, animated: true){
            self.playerViewController.player?.play()
        }

    
    }

    @IBAction func addButton(sender: AnyObject) {
        let image = UIImagePickerController()
        //image.delegate = self
        image.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        self.presentViewController(image, animated: true, completion: nil)

    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let theInfo : NSDictionary =  info as NSDictionary
        let img:UIImage = theInfo.objectForKey(UIImagePickerControllerOriginalImage) as! UIImage
        imageView.image = img
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
}
