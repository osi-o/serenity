//
//  HomeViewController.swift
//  Serenity
//
//  Created by Harold  on 2/29/16.
//  Copyright © 2016 Harold . All rights reserved.
//

import UIKit


class HomeViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.navigationBarHidden = false    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
