//
//  PhotoThumbnailCollectionViewCell.swift
//  
//
//  Created by Harold  on 2/29/16.
//
//

import UIKit

class PhotoThumbnailCollectionViewCell: UICollectionViewCell {
    
}
